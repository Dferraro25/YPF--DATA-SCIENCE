# Data-Science_notebooks-5-y-7
Hola profe!

Descargué el DataFrame **Life Expectancy**, pero en mi caso algunos ejercicios con los nombres de las columnas me dieron distintos. Cuando me di cuenta ya había resuelto todo y no encontré otra versión del archivo para comparar.
Más allá de eso, el resultado general fue el mismo que el de mis compañeras, creo.

¡Gracias!

**Daniela Ferraro**
